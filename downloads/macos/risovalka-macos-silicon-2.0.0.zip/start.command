#!/bin/bash
cd "$(dirname "$0")"
echo "========================================"
echo "🎨 ЗАПУСК РИСОВАЛКИ PRO"
echo "========================================"
echo ""
python3 risovalka.py
