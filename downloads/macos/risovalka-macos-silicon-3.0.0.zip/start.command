#!/bin/bash
cd "$(dirname "$0")"
echo "🎨 Рисовалка Pro 3.0.0"
python3 risovalka.py
