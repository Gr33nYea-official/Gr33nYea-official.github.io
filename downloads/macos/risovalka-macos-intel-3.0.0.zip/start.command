#!/bin/bash
cd "$(dirname "$0")"
echo "========================================"
echo "🎨 РИСОВАЛКА PRO 3.0.0"
echo "========================================"
echo ""
python3 risovalka.py
