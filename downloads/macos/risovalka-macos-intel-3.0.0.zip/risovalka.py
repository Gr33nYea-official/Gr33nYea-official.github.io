#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
from PIL import Image, ImageDraw
import os
import time
import json
from datetime import datetime

class SplashScreen:
    def __init__(self):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.geometry("500x300")
        self.root.configure(bg="#4CAF50")
        self.root.eval('tk::PlaceWindow . center')

        title = tk.Label(self.root, text="🎨 Рисовалка Pro", font=("Arial", 24, "bold"),
                        bg="#4CAF50", fg="white")
        title.pack(pady=50)

        loading = tk.Label(self.root, text="Загрузка...", font=("Arial", 14),
                          bg="#4CAF50", fg="white")
        loading.pack()

        self.progress = tk.Label(self.root, text="█" * 0, font=("Arial", 20),
                                bg="#4CAF50", fg="white")
        self.progress.pack(pady=20)

        version = tk.Label(self.root, text=f"Версия {VERSION}", font=("Arial", 10),
                          bg="#4CAF50", fg="white")
        version.pack(side=tk.BOTTOM, pady=10)

        self.update_progress(0)
        self.root.after(100, self.animate)
        self.root.mainloop()

    def update_progress(self, value):
        self.progress.config(text="█" * value)

    def animate(self):
        for i in range(1, 21):
            self.update_progress(i)
            self.root.update()
            time.sleep(0.05)
        self.root.destroy()

class WelcomeMenu:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Добро пожаловать!")
        self.root.geometry("600x400")
        self.root.configure(bg="#f0f0f0")
        self.root.eval('tk::PlaceWindow . center')

        welcome = tk.Label(self.root, text="Добро пожаловать!", font=("Arial", 20, "bold"),
                          bg="#f0f0f0", fg="#4CAF50")
        welcome.pack(pady=30)

        title = tk.Label(self.root, text="🎨 Рисовалка Pro", font=("Arial", 18), bg="#f0f0f0")
        title.pack()

        btn_frame = tk.Frame(self.root, bg="#f0f0f0")
        btn_frame.pack(pady=40)

        new_btn = tk.Button(btn_frame, text="✨ Новый проект", command=self.new_project,
                           font=("Arial", 14), bg="#4CAF50", fg="white", padx=20, pady=10)
        new_btn.pack(pady=10)

        open_btn = tk.Button(btn_frame, text="📂 Открыть проект", command=self.open_project,
                            font=("Arial", 14), bg="#2196F3", fg="white", padx=20, pady=10)
        open_btn.pack(pady=10)

        self.root.mainloop()

    def new_project(self):
        self.root.destroy()
        app = DrawingApp()

    def open_project(self):
        file_path = filedialog.askopenfilename(
            title="Открыть проект",
            filetypes=[("Project files", "*.json"), ("JSON files", "*.json")]
        )
        if file_path:
            self.root.destroy()
            app = DrawingApp(load_path=file_path)

class DrawingApp:
    def __init__(self, load_path=None):
        self.root = tk.Tk()
        self.root.title("Рисовалка Pro")
        self.root.geometry("1000x700")

        self.pen_color = "#000000"
        self.pen_size = 3
        self.eraser_on = False
        self.last_x = None
        self.last_y = None
        self.filename = None

        self.setup_ui()
        self.setup_canvas()
        self.setup_bindings()

        if load_path:
            self.load_project(load_path)

        self.root.mainloop()

    def setup_ui(self):
        toolbar = tk.Frame(self.root, height=50)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        toolbar.pack_propagate(False)

        self.pen_btn = tk.Button(toolbar, text="✏️ Карандаш", command=self.use_pen)
        self.pen_btn.pack(side=tk.LEFT, padx=2, pady=10)

        self.eraser_btn = tk.Button(toolbar, text="🧽 Ластик", command=self.use_eraser)
        self.eraser_btn.pack(side=tk.LEFT, padx=2, pady=10)

        tk.Label(toolbar, text="Цвет:").pack(side=tk.LEFT, padx=10)
        self.color_btn = tk.Button(toolbar, bg=self.pen_color, width=3, height=1, command=self.choose_color)
        self.color_btn.pack(side=tk.LEFT, padx=2)

        tk.Label(toolbar, text="Размер:").pack(side=tk.LEFT, padx=10)
        self.size_scale = tk.Scale(toolbar, from_=1, to=20, orient=tk.HORIZONTAL,
                                   length=150, command=self.change_size)
        self.size_scale.set(3)
        self.size_scale.pack(side=tk.LEFT, padx=5)

        tk.Button(toolbar, text="💾 Сохранить PNG", command=self.save_image,
                 bg="#4CAF50", fg="white").pack(side=tk.RIGHT, padx=10)

        self.status_bar = tk.Label(self.root, text="Готов к рисованию",
                                   anchor=tk.W, padx=10)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_canvas(self):
        container = tk.Frame(self.root)
        container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.canvas = tk.Canvas(container, bg="white", cursor="cross")
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.image = Image.new("RGB", (1000, 700), "white")
        self.draw = ImageDraw.Draw(self.image)

    def setup_bindings(self):
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_line)
        self.canvas.bind("<ButtonRelease-1>", self.stop_draw)

    def start_draw(self, event):
        self.last_x = event.x
        self.last_y = event.y

    def draw_line(self, event):
        if self.last_x and self.last_y:
            color = "white" if self.eraser_on else self.pen_color
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y,
                                   fill=color, width=self.pen_size,
                                   capstyle=tk.ROUND, smooth=True)
            self.draw.line([self.last_x, self.last_y, event.x, event.y],
                          fill=color, width=self.pen_size)
        self.last_x = event.x
        self.last_y = event.y

    def stop_draw(self, event):
        self.last_x = None
        self.last_y = None

    def use_pen(self):
        self.eraser_on = False
        self.pen_btn.config(relief=tk.SUNKEN)
        self.eraser_btn.config(relief=tk.RAISED)
        self.status_bar.config(text="Режим: Карандаш")

    def use_eraser(self):
        self.eraser_on = True
        self.eraser_btn.config(relief=tk.SUNKEN)
        self.pen_btn.config(relief=tk.RAISED)
        self.status_bar.config(text="Режим: Ластик")

    def choose_color(self):
        color = colorchooser.askcolor(title="Выберите цвет")
        if color[1]:
            self.pen_color = color[1]
            self.color_btn.config(bg=self.pen_color)

    def change_size(self, value):
        self.pen_size = int(value)

    def save_image(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG files", "*.png")]
        )
        if file_path:
            self.image.save(file_path)
            self.status_bar.config(text=f"Сохранено: {os.path.basename(file_path)}")
            messagebox.showinfo("Сохранено", "Рисунок сохранён в формате PNG")

    def load_project(self, path):
        try:
            with open(path, 'r') as f:
                data = json.load(f)
            self.status_bar.config(text=f"Загружено: {os.path.basename(path)}")
        except:
            self.status_bar.config(text="Ошибка загрузки")

if __name__ == "__main__":
    VERSION = "3.0.0"
    splash = SplashScreen()
    menu = WelcomeMenu()
