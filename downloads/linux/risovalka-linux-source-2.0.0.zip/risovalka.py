#!/usr/bin/env python3
import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
from PIL import Image, ImageDraw
import os

class DrawingApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Рисовалка Pro")
        self.root.geometry("1000x700")

        self.pen_color = "#000000"
        self.pen_size = 3
        self.eraser_on = False
        self.last_x = None
        self.last_y = None

        self.setup_ui()
        self.setup_canvas()
        self.setup_bindings()

    def setup_ui(self):
        toolbar = tk.Frame(self.root, height=50)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        toolbar.pack_propagate(False)

        self.pen_btn = tk.Button(toolbar, text="✏️ Карандаш", command=self.use_pen)
        self.pen_btn.pack(side=tk.LEFT, padx=2, pady=10)

        self.eraser_btn = tk.Button(toolbar, text="🧽 Ластик", command=self.use_eraser)
        self.eraser_btn.pack(side=tk.LEFT, padx=2, pady=10)

        tk.Label(toolbar, text="Цвет:").pack(side=tk.LEFT, padx=10)
        self.color_btn = tk.Button(toolbar, bg=self.pen_color, width=3, height=1, command=self.choose_color)
        self.color_btn.pack(side=tk.LEFT, padx=2)

        tk.Label(toolbar, text="Размер:").pack(side=tk.LEFT, padx=10)
        self.size_scale = tk.Scale(toolbar, from_=1, to=20, orient=tk.HORIZONTAL, length=150, command=self.change_size)
        self.size_scale.set(3)
        self.size_scale.pack(side=tk.LEFT, padx=5)

        tk.Button(toolbar, text="💾 Сохранить", command=self.save_image, bg="#4CAF50", fg="white").pack(side=tk.RIGHT, padx=10)

        self.status_bar = tk.Label(self.root, text="Готов к рисованию", anchor=tk.W, padx=10)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def setup_canvas(self):
        container = tk.Frame(self.root)
        container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.canvas = tk.Canvas(container, bg="white", cursor="cross")
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.image = Image.new("RGB", (1000, 700), "white")
        self.draw = ImageDraw.Draw(self.image)

    def setup_bindings(self):
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_line)
        self.canvas.bind("<ButtonRelease-1>", self.stop_draw)

    def start_draw(self, event):
        self.last_x = event.x
        self.last_y = event.y

    def draw_line(self, event):
        if self.last_x and self.last_y:
            color = "white" if self.eraser_on else self.pen_color
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y,
                                   fill=color, width=self.pen_size, capstyle=tk.ROUND, smooth=True)
            self.draw.line([self.last_x, self.last_y, event.x, event.y], fill=color, width=self.pen_size)
        self.last_x = event.x
        self.last_y = event.y

    def stop_draw(self, event):
        self.last_x = None
        self.last_y = None

    def use_pen(self):
        self.eraser_on = False
        self.pen_btn.config(relief=tk.SUNKEN)
        self.eraser_btn.config(relief=tk.RAISED)

    def use_eraser(self):
        self.eraser_on = True
        self.eraser_btn.config(relief=tk.SUNKEN)
        self.pen_btn.config(relief=tk.RAISED)

    def choose_color(self):
        color = colorchooser.askcolor(title="Выберите цвет")
        if color[1]:
            self.pen_color = color[1]
            self.color_btn.config(bg=self.pen_color)

    def change_size(self, value):
        self.pen_size = int(value)

    def save_image(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
        if file_path:
            self.image.save(file_path)
            self.status_bar.config(text=f"Сохранено: {os.path.basename(file_path)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = DrawingApp(root)
    root.mainloop()
