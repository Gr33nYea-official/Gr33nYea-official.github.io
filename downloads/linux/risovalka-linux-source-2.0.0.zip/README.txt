========================================
🎨 РИСОВАЛКА PRO - Linux версия 2.0.0
========================================

📥 УСТАНОВКА:

1. Установите Python 3 (если не установлен):
   Ubuntu/Debian:
     sudo apt update
     sudo apt install python3 python3-pip

   Fedora/RHEL:
     sudo dnf install python3 python3-pip

   Arch Linux:
     sudo pacman -S python python-pip

2. Установите библиотеку Pillow:
   pip3 install Pillow

3. Установите tkinter (ВАЖНО!):
   Ubuntu/Debian:
     sudo apt install python3-tk

   Fedora/RHEL:
     sudo dnf install python3-tkinter

   Arch Linux:
     sudo pacman -S python-tk

🚀 ЗАПУСК:
- Через терминал: python3 risovalka.py
- Или сделайте файл исполняемым и запустите:
  chmod +x start.sh
  ./start.sh

🖱️ КАК ПОЛЬЗОВАТЬСЯ:
- Рисование: зажмите левую кнопку мыши
- Смена цвета: нажмите на цветной квадратик
- Размер кисти: двигайте ползунок
- Ластик: нажмите кнопку "Ластик"
- Сохранение: кнопка "💾 Сохранить"

📂 ФАЙЛЫ:
- risovalka.py - основная программа
- start.sh - скрипт запуска
- README.txt - эта инструкция

❓ ЧАСТЫЕ ПРОБЛЕМЫ:

1. Ошибка "No module named PIL":
   pip3 install Pillow

2. Ошибка "No module named tkinter":
   sudo apt install python3-tk  (Ubuntu/Debian)
   sudo dnf install python3-tkinter  (Fedora)

3. Ошибка прав доступа:
   chmod +x start.sh
   ./start.sh

========================================
💖 От Gr33nYea
========================================
