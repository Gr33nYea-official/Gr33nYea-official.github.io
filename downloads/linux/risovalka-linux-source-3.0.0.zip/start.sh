#!/bin/bash
echo "🎨 Рисовалка Pro 3.0.0"
python3 risovalka.py
