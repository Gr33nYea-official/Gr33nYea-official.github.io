#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import colorchooser, filedialog, messagebox
from PIL import Image, ImageDraw, ImageTk
import os
import time
import json
import pickle
from datetime import datetime

# ========================================
# КЛАСС ПРОЕКТА
# ========================================
class RisovalkaProject:
    def __init__(self, name="Новый проект"):
        self.name = name
        self.created = datetime.now().isoformat()
        self.modified = self.created
        self.version = "3.0.0"

    def to_dict(self):
        return {
            "name": self.name,
            "created": self.created,
            "modified": self.modified,
            "version": self.version
        }

# ========================================
# ЭКРАН ЗАГРУЗКИ
# ========================================
class SplashScreen:
    def __init__(self):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.geometry("500x300")
        self.root.configure(bg="#4CAF50")
        self.root.eval('tk::PlaceWindow . center')

        title = tk.Label(self.root, text="🎨 Рисовалка Pro", font=("Arial", 24, "bold"),
                        bg="#4CAF50", fg="white")
        title.pack(pady=50)

        loading = tk.Label(self.root, text="Загрузка...", font=("Arial", 14),
                          bg="#4CAF50", fg="white")
        loading.pack()

        self.progress = tk.Label(self.root, text="█" * 0, font=("Arial", 20),
                                bg="#4CAF50", fg="white")
        self.progress.pack(pady=20)

        version = tk.Label(self.root, text="Версия 3.0.0", font=("Arial", 10),
                          bg="#4CAF50", fg="white")
        version.pack(side=tk.BOTTOM, pady=10)

        self.update_progress(0)
        self.root.after(100, self.animate)
        self.root.mainloop()

    def update_progress(self, value):
        self.progress.config(text="█" * value)

    def animate(self):
        for i in range(1, 21):
            self.update_progress(i)
            self.root.update()
            time.sleep(0.05)
        self.root.destroy()

# ========================================
# МЕНЮ ПРОЕКТОВ
# ========================================
class ProjectMenu:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Добро пожаловать!")
        self.root.geometry("600x400")
        self.root.configure(bg="#f0f0f0")
        self.root.eval('tk::PlaceWindow . center')

        welcome = tk.Label(self.root, text="Добро пожаловать!", font=("Arial", 24, "bold"),
                          bg="#f0f0f0", fg="#4CAF50")
        welcome.pack(pady=30)

        title = tk.Label(self.root, text="🎨 Рисовалка Pro", font=("Arial", 18), bg="#f0f0f0")
        title.pack()

        btn_frame = tk.Frame(self.root, bg="#f0f0f0")
        btn_frame.pack(pady=40)

        new_btn = tk.Button(btn_frame, text="✨ НОВЫЙ ПРОЕКТ", command=self.new_project,
                           font=("Arial", 16), bg="#4CAF50", fg="white",
                           width=20, height=2, cursor="hand2")
        new_btn.pack(pady=10)

        open_btn = tk.Button(btn_frame, text="📂 ОТКРЫТЬ ПРОЕКТ", command=self.open_project,
                            font=("Arial", 16), bg="#2196F3", fg="white",
                            width=20, height=2, cursor="hand2")
        open_btn.pack(pady=10)

        info = tk.Label(self.root, text="Версия 3.0.0 | Поддерживаются: GRP, JSON, PNG, JPG, BMP, GIF, TIFF",
                       font=("Arial", 10), bg="#f0f0f0", fg="#666")
        info.pack(side=tk.BOTTOM, pady=20)

        self.root.mainloop()

    def new_project(self):
        self.root.destroy()
        app = DrawingApp()

    def open_project(self):
        file_path = filedialog.askopenfilename(
            title="Открыть проект",
            filetypes=[
                ("GRP проекты", "*.grp"),
                ("JSON проекты", "*.json"),
                ("PNG изображения", "*.png"),
                ("JPEG изображения", "*.jpg"),
                ("BMP изображения", "*.bmp"),
                ("GIF изображения", "*.gif"),
                ("TIFF изображения", "*.tiff"),
                ("Все файлы", "*.*")
            ]
        )
        if file_path:
            self.root.destroy()
            app = DrawingApp(load_file=file_path)

# ========================================
# ОСНОВНОЕ ПРИЛОЖЕНИЕ
# ========================================
class DrawingApp:
    def __init__(self, load_file=None):
        self.root = tk.Tk()
        self.root.title("Рисовалка Pro")
        self.root.geometry("1000x700")

        self.pen_color = "#000000"
        self.pen_size = 3
        self.eraser_on = False
        self.last_x = None
        self.last_y = None
        self.current_project = RisovalkaProject()
        self.current_file = None
        self.image = None
        self.draw = None
        self.tk_image = None

        self.setup_menu()
        self.setup_ui()
        self.setup_canvas()
        self.setup_bindings()

        if load_file:
            self.load_project(load_file)

        self.root.mainloop()

    def setup_menu(self):
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Файл", menu=file_menu)

        file_menu.add_command(label="✨ Новый проект", command=self.new_project, accelerator="Ctrl+N")
        file_menu.add_command(label="📂 Открыть проект...", command=self.open_project, accelerator="Ctrl+O")
        file_menu.add_separator()
        file_menu.add_command(label="💾 Сохранить (GRP)", command=self.save_project, accelerator="Ctrl+S")
        file_menu.add_command(label="💾 Сохранить как...", command=self.save_project_as)
        file_menu.add_separator()

        export_menu = tk.Menu(file_menu, tearoff=0)
        file_menu.add_cascade(label="📤 Экспортировать как", menu=export_menu)
        export_menu.add_command(label="PNG изображение", command=lambda: self.export_image("png"))
        export_menu.add_command(label="JPEG изображение", command=lambda: self.export_image("jpg"))
        export_menu.add_command(label="BMP изображение", command=lambda: self.export_image("bmp"))
        export_menu.add_command(label="GIF изображение", command=lambda: self.export_image("gif"))
        export_menu.add_command(label="TIFF изображение", command=lambda: self.export_image("tiff"))
        export_menu.add_separator()
        export_menu.add_command(label="JSON (метаданные)", command=self.export_json)

        file_menu.add_separator()
        file_menu.add_command(label="❌ Выход", command=self.root.quit)

        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Правка", menu=edit_menu)
        edit_menu.add_command(label="🗑 Очистить всё", command=self.clear_canvas)

        self.root.bind('<Control-n>', lambda e: self.new_project())
        self.root.bind('<Control-o>', lambda e: self.open_project())
        self.root.bind('<Control-s>', lambda e: self.save_project())

    def setup_ui(self):
        toolbar = tk.Frame(self.root, height=50)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        toolbar.pack_propagate(False)

        menu_btn = tk.Button(toolbar, text="🏠 Меню проектов", command=self.return_to_menu,
                            bg="#9C27B0", fg="white", padx=10)
        menu_btn.pack(side=tk.LEFT, padx=5, pady=10)

        sep = tk.Frame(toolbar, width=2, height=30, bg="#ccc")
        sep.pack(side=tk.LEFT, padx=5)

        self.pen_btn = tk.Button(toolbar, text="✏️ Карандаш", command=self.use_pen,
                                 relief=tk.SUNKEN)
        self.pen_btn.pack(side=tk.LEFT, padx=2, pady=10)

        self.eraser_btn = tk.Button(toolbar, text="🧽 Ластик", command=self.use_eraser,
                                    relief=tk.RAISED)
        self.eraser_btn.pack(side=tk.LEFT, padx=2, pady=10)

        tk.Label(toolbar, text="Цвет:").pack(side=tk.LEFT, padx=10)
        self.color_btn = tk.Button(toolbar, bg=self.pen_color, width=3, height=1,
                                   command=self.choose_color)
        self.color_btn.pack(side=tk.LEFT, padx=2)

        tk.Label(toolbar, text="Размер:").pack(side=tk.LEFT, padx=10)
        self.size_scale = tk.Scale(toolbar, from_=1, to=20, orient=tk.HORIZONTAL,
                                   length=150, command=self.change_size)
        self.size_scale.set(3)
        self.size_scale.pack(side=tk.LEFT, padx=5)

        tk.Button(toolbar, text="💾 GRP", command=self.save_project,
                 bg="#4CAF50", fg="white", padx=10).pack(side=tk.RIGHT, padx=2)

        tk.Button(toolbar, text="📷 PNG", command=lambda: self.export_image("png"),
                 bg="#FF9800", fg="white", padx=10).pack(side=tk.RIGHT, padx=2)

        status_frame = tk.Frame(self.root)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)

        self.status_bar = tk.Label(status_frame, text="Готов к рисованию",
                                   anchor=tk.W, padx=10)
        self.status_bar.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.project_label = tk.Label(status_frame, text="Проект: Новый проект",
                                      anchor=tk.E, padx=10)
        self.project_label.pack(side=tk.RIGHT)

    def setup_canvas(self):
        container = tk.Frame(self.root)
        container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.canvas = tk.Canvas(container, bg="white", cursor="cross")
        self.canvas.pack(fill=tk.BOTH, expand=True)

        self.new_image()

    def new_image(self):
        self.image = Image.new("RGB", (1000, 700), "white")
        self.draw = ImageDraw.Draw(self.image)

    def setup_bindings(self):
        self.canvas.bind("<Button-1>", self.start_draw)
        self.canvas.bind("<B1-Motion>", self.draw_line)
        self.canvas.bind("<ButtonRelease-1>", self.stop_draw)

    def start_draw(self, event):
        self.last_x = event.x
        self.last_y = event.y

    def draw_line(self, event):
        if self.last_x and self.last_y:
            color = "white" if self.eraser_on else self.pen_color
            self.canvas.create_line(self.last_x, self.last_y, event.x, event.y,
                                   fill=color, width=self.pen_size,
                                   capstyle=tk.ROUND, smooth=True)
            self.draw.line([self.last_x, self.last_y, event.x, event.y],
                          fill=color, width=self.pen_size)
        self.last_x = event.x
        self.last_y = event.y

    def stop_draw(self, event):
        self.last_x = None
        self.last_y = None

    def use_pen(self):
        self.eraser_on = False
        self.pen_btn.config(relief=tk.SUNKEN)
        self.eraser_btn.config(relief=tk.RAISED)
        self.status_bar.config(text="Режим: Карандаш")

    def use_eraser(self):
        self.eraser_on = True
        self.eraser_btn.config(relief=tk.SUNKEN)
        self.pen_btn.config(relief=tk.RAISED)
        self.status_bar.config(text="Режим: Ластик")

    def choose_color(self):
        color = colorchooser.askcolor(title="Выберите цвет")
        if color[1]:
            self.pen_color = color[1]
            self.color_btn.config(bg=self.pen_color)

    def change_size(self, value):
        self.pen_size = int(value)

    def new_project(self):
        if messagebox.askyesno("Новый проект", "Создать новый проект?\nВсе несохраненные изменения будут потеряны."):
            self.canvas.delete("all")
            self.new_image()
            self.current_project = RisovalkaProject("Новый проект")
            self.current_file = None
            self.project_label.config(text="Проект: Новый проект")
            self.status_bar.config(text="Новый проект создан")

    def open_project(self):
        file_path = filedialog.askopenfilename(
            title="Открыть проект",
            filetypes=[
                ("GRP проекты", "*.grp"),
                ("JSON проекты", "*.json"),
                ("PNG изображения", "*.png"),
                ("JPEG изображения", "*.jpg"),
                ("BMP изображения", "*.bmp"),
                ("GIF изображения", "*.gif"),
                ("TIFF изображения", "*.tiff"),
                ("Все файлы", "*.*")
            ]
        )
        if file_path:
            self.load_project(file_path)

    def load_project(self, file_path):
        try:
            if file_path.endswith('.grp'):
                with open(file_path, 'rb') as f:
                    data = pickle.load(f)
                    self.current_project = data['project']
                    if 'image_data' in data:
                        self.image = data['image_data']
                        self.draw = ImageDraw.Draw(self.image)
                        self.canvas.delete("all")
                        self.tk_image = ImageTk.PhotoImage(self.image)
                        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_image)
                        self.status_bar.config(text="✅ Загружен GRP проект с изображением")

            elif file_path.endswith('.json'):
                with open(file_path, 'r') as f:
                    data = json.load(f)
                    self.current_project = RisovalkaProject(data.get('name', 'Проект'))
                    self.status_bar.config(text="📄 Загружен JSON проект (метаданные)")
                    self.new_image()

            elif file_path.endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tiff')):
                self.image = Image.open(file_path)
                if self.image.size != (1000, 700):
                    self.image = self.image.resize((1000, 700), Image.Resampling.LANCZOS)
                self.draw = ImageDraw.Draw(self.image)
                self.canvas.delete("all")
                self.tk_image = ImageTk.PhotoImage(self.image)
                self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_image)
                self.status_bar.config(text=f"🖼️ Загружено изображение")
                self.current_project = RisovalkaProject(os.path.basename(file_path))

            self.current_file = file_path
            name = os.path.basename(file_path)
            self.project_label.config(text=f"Проект: {name}")

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить:\n{str(e)}")

    def save_project(self):
        if self.current_file and self.current_file.endswith('.grp'):
            self._save_grp(self.current_file)
        else:
            self.save_project_as()

    def save_project_as(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".grp",
            filetypes=[
                ("GRP проекты", "*.grp"),
                ("JSON метаданные", "*.json"),
                ("Все файлы", "*.*")
            ]
        )
        if file_path:
            if file_path.endswith('.grp'):
                self._save_grp(file_path)
            elif file_path.endswith('.json'):
                self._save_json(file_path)

    def _save_grp(self, file_path):
        try:
            self.current_project.modified = datetime.now().isoformat()
            self.current_project.name = os.path.basename(file_path)

            data = {
                'project': self.current_project,
                'image_data': self.image,
                'version': '3.0.0'
            }

            with open(file_path, 'wb') as f:
                pickle.dump(data, f)

            self.current_file = file_path
            self.project_label.config(text=f"Проект: {os.path.basename(file_path)}")
            self.status_bar.config(text=f"💾 Сохранено: GRP с изображением")
            messagebox.showinfo("Сохранено", "Проект сохранён в формате GRP")

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить:\n{str(e)}")

    def _save_json(self, file_path):
        try:
            data = self.current_project.to_dict()
            with open(file_path, 'w') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            self.status_bar.config(text="📄 Экспортировано: JSON метаданные")
            messagebox.showinfo("Сохранено", "Метаданные проекта экспортированы в JSON")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось сохранить JSON:\n{str(e)}")

    def export_image(self, format_type):
        format_names = {
            "png": "PNG изображение",
            "jpg": "JPEG изображение",
            "bmp": "BMP изображение",
            "gif": "GIF изображение",
            "tiff": "TIFF изображение"
        }

        file_path = filedialog.asksaveasfilename(
            defaultextension=f".{format_type}",
            filetypes=[(format_names[format_type], f"*.{format_type}"), ("Все файлы", "*.*")]
        )

        if file_path:
            try:
                if format_type == "jpg":
                    rgb_image = Image.new('RGB', self.image.size, (255, 255, 255))
                    rgb_image.paste(self.image)
                    rgb_image.save(file_path, quality=95)
                else:
                    self.image.save(file_path)

                self.status_bar.config(text=f"🖼️ Экспортировано: {os.path.basename(file_path)}")
                messagebox.showinfo("Экспорт", f"Изображение сохранено как {format_type.upper()}")

            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось экспортировать:\n{str(e)}")

    def export_json(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON файлы", "*.json"), ("Все файлы", "*.*")]
        )
        if file_path:
            self._save_json(file_path)

    def clear_canvas(self):
        if messagebox.askyesno("Очистка", "Очистить холст?"):
            self.canvas.delete("all")
            self.new_image()
            self.status_bar.config(text="Холст очищен")

    def return_to_menu(self):
        if messagebox.askyesno("Меню проектов", "Вернуться в меню проектов?\nНесохраненные изменения будут потеряны."):
            self.root.destroy()
            menu = ProjectMenu()

if __name__ == "__main__":
    splash = SplashScreen()
    menu = ProjectMenu()
