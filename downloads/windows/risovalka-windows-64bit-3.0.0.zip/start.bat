@echo off
echo 🎨 Рисовалка Pro 3.0.0
python risovalka.py
pause
