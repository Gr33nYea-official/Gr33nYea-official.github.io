@echo off
echo ========================================
echo 🎨 РИСОВАЛКА PRO 3.0.0
echo ========================================
echo.
python risovalka.py
pause
