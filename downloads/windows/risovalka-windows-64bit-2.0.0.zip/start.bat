@echo off
echo ========================================
echo 🎨 ЗАПУСК РИСОВАЛКИ PRO
echo ========================================
echo.
python risovalka.py
pause
